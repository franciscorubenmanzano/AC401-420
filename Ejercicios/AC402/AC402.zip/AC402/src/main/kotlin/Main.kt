fun main(args: Array<String>) {

    val enteros= arrayListOf<Int>()


    println("ingrese 3 numeros enteros")
        enteros.add(excepcion_entero())
        enteros.add(excepcion_entero())
        enteros.add(excepcion_entero())

    val promedio = enteros.sum()/3
    val cuadrado = enteros.map { it*it }
    val binario = enteros.map { Integer.toBinaryString(it) }

    println("El promedio es: $promedio")
    println("El cuadrado de los numeros es: $cuadrado")
    println("El numero en binario es: $binario")


    }

fun excepcion_entero(): Int { //funcion para controla la excepcion
    while (true) {
        try {
            return readLine()!!.toInt()
        } catch (e: Exception) {
            println("Ingrese un número válido")
        }
    }
}
